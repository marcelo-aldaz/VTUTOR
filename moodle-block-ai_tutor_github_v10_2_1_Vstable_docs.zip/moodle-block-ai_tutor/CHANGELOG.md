# Changelog (Registro de cambios)

## [10.2.1] - Vstable (Producción)
### Mejoras
- Base estable con UX flotante
- Panel RAG experimental neutralizado/desactivado en la línea estable
- Limpieza visual de etiqueta `courseid` (si aparece en admin)

### Notas
- Versión recomendada para producción (**Vstable**)

## [10.2.0] - Base estable UX flotante
- Interfaz flotante
- Mejor lectura de respuestas extensas

## [11.x] - Experimental (No estable)
- RAG / indexación / diagnóstico (rama experimental)
