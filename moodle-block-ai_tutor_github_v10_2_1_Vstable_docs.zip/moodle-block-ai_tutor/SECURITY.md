# Política de seguridad

## Versiones soportadas
- Línea estable: `v10.2.1`
- Las ramas experimentales no se consideran listas para producción

## Reporte de vulnerabilidades
No publique primero vulnerabilidades sensibles de forma pública.
Incluya versión, Moodle, pasos para reproducir e impacto.
