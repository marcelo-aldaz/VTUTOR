## Resumen
¿Qué cambia este PR?

## Tipo de cambio
- [ ] Bug fix
- [ ] Mejora UX
- [ ] Documentación
- [ ] Experimental (RAG)

## Pruebas
- [ ] Instalado en Moodle de pruebas
- [ ] Chat funciona
- [ ] Sin errores fatales en admin
