---
name: Bug report
about: Reportar un problema en VTutor
title: "[BUG] "
labels: bug
---

## Entorno
- Moodle:
- PHP:
- Plugin:
- Tema/Formato de curso:

## Descripción
## Pasos para reproducir
1.
2.
3.

## Error / stack trace
Pegar aquí.
