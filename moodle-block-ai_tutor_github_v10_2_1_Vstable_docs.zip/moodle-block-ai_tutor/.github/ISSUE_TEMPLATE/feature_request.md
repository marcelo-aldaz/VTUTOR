---
name: Feature request
about: Sugerir una mejora para VTutor
title: "[FEATURE] "
labels: enhancement
---

## Resumen
## Caso de uso
## Solución propuesta
