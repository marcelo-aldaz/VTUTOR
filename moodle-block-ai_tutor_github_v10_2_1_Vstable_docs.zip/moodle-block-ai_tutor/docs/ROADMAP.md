# Hoja de ruta (Roadmap)

## Línea estable (v10.2.x)
### v10.2.1 (Vstable)
- UX flotante estable
- Panel RAG desactivado en línea estable

### v10.2.2 (pruebas)
- Mejoras UX visual
- Mejor móvil/tablet
- Menos ruido markdown
- Scroll más estable

## Línea experimental (v11-RAG)
- Diagnóstico RAG
- Indexación por curso
- Retrieval contextual
- Lectura de archivos
