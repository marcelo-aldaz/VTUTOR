# VTutor v10.2.1 (Vstable)

## Resumen
Versión estable de producción (Vstable) para VTutor en Moodle.

## Estado
- ✅ Recomendada para producción
- ✅ Validada en entorno real
- ⚠️ RAG avanzado fuera de esta línea

## Incluye
- UX flotante estable
- Panel RAG experimental neutralizado/desactivado
- Limpieza visual de etiquetas administrativas (si aplica)

## No incluye (intencionalmente)
- RAG avanzado / diagnóstico / reindexación / lectura automática de archivos
