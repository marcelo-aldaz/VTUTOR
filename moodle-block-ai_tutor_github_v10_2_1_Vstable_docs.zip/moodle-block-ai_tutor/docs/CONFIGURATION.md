# Guía de configuración

## Campos generales (pueden variar)
- Proveedor
- URL base / Endpoint
- API Key
- Modelo
- Timeout (opcional)
- Temperatura (opcional)

## Recomendación
- Mantener `v10.2.1` en producción
- Probar cambios en un curso no crítico
